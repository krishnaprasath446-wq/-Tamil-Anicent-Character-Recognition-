# Kalvettu
Indentifying single character from scaled and normalised image.
OCR model is yet to be built to feed formatted image to the model from camera.
